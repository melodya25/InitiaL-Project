package com.tambak.app.interfaces;

/**
 *  Created by dz_melodya
 *  Tanjungpinang - Kepulauan Riau 12/12/20
 *  Copyright (c) 2020. All rights reserved.
 *  dz.melodya@hotmail.com
 *  tambak.app@gmail.com
 */


public interface ContextualModeInteractor {
    void enableContextualMode();

    boolean isContextualMode();

    void updateSelectedCount(int count);
}
