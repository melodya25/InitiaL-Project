package com.tambak.app.interfaces;

import com.tambak.app.models.Contact;
import com.tambak.app.models.User;

import java.util.ArrayList;

/**
 *  Created by dz_melodya
 *  Tanjungpinang - Kepulauan Riau 12/12/20
 *  Copyright (c) 2020. All rights reserved.
 *  dz.melodya@hotmail.com
 *  tambak.app@gmail.com
 */


public interface HomeIneractor {
    User getUserMe();

    ArrayList<Contact> getLocalContacts();

}
