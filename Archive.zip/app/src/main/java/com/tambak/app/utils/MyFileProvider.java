package com.tambak.app.utils;

import android.support.v4.content.FileProvider;

/**
 *  Created by dz_melodya
 *  Tanjungpinang - Kepulauan Riau 12/12/20
 *  Copyright (c) 2020. All rights reserved.
 *  dz.melodya@hotmail.com
 *  tambak.app@gmail.com
 */

public class MyFileProvider extends FileProvider {
}
