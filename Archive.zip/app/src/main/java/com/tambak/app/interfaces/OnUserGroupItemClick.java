package com.tambak.app.interfaces;

import android.view.View;

import com.tambak.app.models.Group;
import com.tambak.app.models.User;

/**
 *  Created by dz_melodya
 *  Tanjungpinang - Kepulauan Riau 12/12/20
 *  Copyright (c) 2020. All rights reserved.
 *  dz.melodya@hotmail.com
 *  tambak.app@gmail.com
 */


public interface OnUserGroupItemClick {
    void OnUserClick(User user, int position, View userImage);
    void OnGroupClick(Group group, int position, View userImage);
}
