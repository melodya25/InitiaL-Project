package com.tambak.app.utils;

import com.tambak.app.R;

import java.util.Random;

/**
 *  Created by dz_melodya
 *  Tanjungpinang - Kepulauan Riau 12/12/20
 *  Copyright (c) 2020. All rights reserved.
 *  dz.melodya@hotmail.com
 *  tambak.app@gmail.com
 */

public class RandomColorGenerator {

    private static final int[] COLORS = new int[] {R.color.blue,
            R.color.purple,
            R.color.green,
            R.color.orange,
            R.color.red,
            R.color.darkBlue,
            R.color.darkPurple,
            R.color.darkGreen,
            R.color.darkOrange,
            R.color.darkRed};

    private static final Random RANDOM = new Random();

    public static Integer getColor() {
        return COLORS[RANDOM.nextInt(COLORS.length)];
    }
}
